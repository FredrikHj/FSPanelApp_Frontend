com.redwhitesilver.rotarySwitch
===============================

Rotary switch plugin for jQuery

### Documentation and examples:

[rotaryswitch.redwhitesilver.com](http://rotaryswitch.redwhitesilver.com)

### Licence

Apache 2.0